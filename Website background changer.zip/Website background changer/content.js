var images = document.getElementsByTagName('img', 'iframe', 'button');
for (var i = 0, l = images.length; i < l; i++) {
  images[i].src = 'https://media.tenor.com/IIXy6CqR5l8AAAAC/mrbeast-ytpmv.gif'}
