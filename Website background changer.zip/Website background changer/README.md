# Mrbeast-takeover
Change most the images on screen to mrbeast (from the mrbeast rap) and also, just change the background




# How To Install
1. Download the latest version of the extension.
2. Make sure you have developer mode turned on.
3. Click load unpacked.
4. Choose the Mrbeast-takeover file.
# Updates
none, yet,
